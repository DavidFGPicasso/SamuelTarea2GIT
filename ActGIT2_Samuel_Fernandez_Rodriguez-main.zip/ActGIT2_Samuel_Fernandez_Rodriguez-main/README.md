## Pagina Web Escolar
Aqui Estaremos realizando una pagina web para consultar el horario de clases


### Instalación
1. Clona este repositorio: `git clone https://github.com/Samus5/ActGIT2_Samuel_Fernandez_Rodriguez.git`
2. Navega al directorio del proyecto: `cd Act2GIT_Samuel_Fernandez_Rodriguez`


### Contribución
¡Agradecemos las contribuciones! Para contribuir al proyecto, sigue estos pasos:
1. Haz un fork del repositorio
2. Crea una nueva rama: `git checkout -b feature/nueva-caracteristica`
3. Realiza tus cambios y haz commit: `git commit -m 'Añade nueva característica'`
4. Haz push a la rama: `git push origin feature/nueva-caracteristica`
5. Abre un pull request en GitHub
